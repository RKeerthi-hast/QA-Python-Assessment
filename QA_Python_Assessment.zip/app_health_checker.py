
import requests
import datetime

def check_website(url):
    now = datetime.datetime.now()
    try:
        response = requests.get(url, timeout=5)
        status = response.status_code
        result = "UP" if status == 200 else f"DOWN (Status Code: {status})"
    except requests.exceptions.RequestException as e:
        result = f"DOWN (Error: {e})"

    log = f"[{now}] - Checked {url} - Result: {result}\n"

    with open("app_health_log.txt", "a") as file:
        file.write(log)

if __name__ == "__main__":
    check_website("https://www.google.com")

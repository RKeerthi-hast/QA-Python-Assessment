
import psutil
import datetime

def get_system_health():
    now = datetime.datetime.now()
    cpu = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory().percent
    disk = psutil.disk_usage('/').percent

    report = (
        f"--- System Health Report ({now}) ---\n"
        f"CPU Usage: {cpu}%\n"
        f"Memory Usage: {memory}%\n"
        f"Disk Usage: {disk}%\n"
        f"{'-'*40}\n"
    )

    with open("system_health_log.txt", "a") as f:
        f.write(report)

if __name__ == "__main__":
    get_system_health()

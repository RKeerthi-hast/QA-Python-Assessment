
# QA Practical Assessment - Python Scripts

## Script 1: System Health Monitor
- Checks CPU, memory, and disk usage using the `psutil` library.
- Output is written to a file called `system_health_log.txt`.

### How to Run:
1. Install the library (if not already): `pip install psutil`
2. Run the script: `python system_health_monitor.py`

---

## Script 2: Application Health Checker
- Sends a request to https://www.google.com to check if it is up.
- Saves the result in `app_health_log.txt`.

### How to Run:
1. Install the library (if not already): `pip install requests`
2. Run the script: `python app_health_checker.py`
